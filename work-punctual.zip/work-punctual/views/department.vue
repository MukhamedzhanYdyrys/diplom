<template>
    <div class="sidebar">
        <div class="sidebar-header">
          <h3>Work Punctual</h3>
        </div>
        <ul class="sidebar-menu">
          <li @click="goToDepartments" class="sidebar-menu-item choosed"><a >Departments</a></li>
          <li @click="goToEmployees" class="sidebar-menu-item"><a >Employees</a></li>
          <li @click="goToProfile" class="sidebar-menu-item"><a >Profile</a></li>
          <li @click="goToZones" class="sidebar-menu-item"><a >Zones</a></li>
          <li @click="goToChecklists" class="sidebar-menu-item"><a>Checklists</a></li>
          <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
        </ul>
    </div>
    <div class="employee_info">
        <h1>Edit Department</h1>
        <form @submit.prevent="updateDepartment">
            <label for="name">Name:</label>
            <input type="text" id="name" v-model="editedDepartment.name"><br>

            <label for="head_of_department_id">Head of Department:</label>
            <select v-model="editedDepartment.head_of_department_id" id="head_of_department_id">
                <option v-for="head in heads" :key="head.id" :value="head.id">
                    {{ head.user.first_name }} {{ head.user.last_name }}
                </option>
            </select><br>

            <label for="zones">Zone</label>
            <select v-model="editedDepartment.zones" multiple id="zones">
                <option v-for="zone in zones" :key="zone.id" :value="zone.id">
                    {{ zone.address }}
                </option>
            </select><br>

            <div v-for="(schedule, index) in editedDepartment.schedules" :key="index">
                    <h3>Schedule {{ daysOfWeek[schedule.week_day] }}</h3>
                    <input type="checkbox" :id="'editable-' + index" v-model="schedule.editable">
                    <label :for="'editable-' + index">Enable Editing</label><br>

                    <label for="time_from">Time From:</label>
                    <input type="time" v-model="schedule.time_from" :disabled="!schedule.editable"><br>

                    <label for="time_to">Time To:</label>
                    <input type="time" v-model="schedule.time_to" :disabled="!schedule.editable"><br>

                </div>

            <button type="submit">Save Changes</button>
        </form>
    </div>

</template>

<script>
import axios from 'axios'

export default {
    data() {
        return {
            companyId: null,
            departments2: [],
            editingMode: false,
            zones:[],
            editedDepartment: {
                name: '',
                zones: [],
                schedules: this.initializeSchedules(),
                timezone: '+05:00'
            },
            heads: [],
            daysOfWeek: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        }
    },created() {
        this.initialize();
    },
    methods: {
        async logout() {
            this.$root.logout();
            localStorage.removeItem('authToken');
            this.$router.push('/');
        },
        goToDepartments() {
            this.$router.push({ name: 'departments' });
        },
        goToEmployees() {
            this.$router.push({ name: 'employees' });
        },
        goToProfile() {
              this.$router.push({ name: 'profile' });
        },
        goToZones() {
              this.$router.push({ name: 'zones' });
        },
        goToChecklists() {
            this.$router.push({ name: 'Checklists' });
        },
        async initialize() {
            await this.fetchCompanyId();
            await this.fetchZoneList();
            await this.fetchDepartment();
            await this.fetchHeadDepartments();
        },
        async fetchCompanyId() {
                const authToken = localStorage.getItem('authToken');
                try {
                    const profileResponse = await axios.get(`https://workpunc.xyz/api/profile/owner/`, {
                        headers: {
                            'Authorization': `Bearer ${authToken}`,
                            'Content-Type': 'application/json'
                        }
                    });
                    this.companyId = profileResponse.data.selected_company.id; 
                } catch (error) {
                    console.error("Error fetching company ID:", error);
                }
            },
        async fetchDepartment() {
            const authToken = localStorage.getItem('authToken');
            const departmentId = this.$route.query.id;
            try {
                const response = await axios.get(`https://workpunc.xyz/api/departments/${departmentId}/`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.editedDepartment = response.data;

                const existingSchedules = this.editedDepartment.schedules || [];
                const fullSchedules = this.initializeSchedules();

                this.editedDepartment.schedules = fullSchedules.map(fullSchedule => {
                    const existingSchedule = existingSchedules.find(s => s.week_day === fullSchedule.week_day);
                    return existingSchedule ? { ...fullSchedule, ...existingSchedule, editable: !!existingSchedule.time_from && !!existingSchedule.time_to } : fullSchedule;
                });
            } catch (error) {
                console.error("Error fetching employee:", error);
            }
        },
        async updateDepartment() {
            const authToken = localStorage.getItem('authToken');
            const departmentId = this.$route.query.id;
            const selectedZoneId = this.editedDepartment.zones;
            const zoneIds = Array.isArray(selectedZoneId) ? selectedZoneId : [selectedZoneId];
            this.editedDepartment.zones = zoneIds;

            this.editedDepartment.schedules.forEach(schedule => {
                schedule.time_from = this.removeSeconds(schedule.time_from);
                schedule.time_to = this.removeSeconds(schedule.time_to);
            });

            const editableSchedules = this.editedDepartment.schedules.filter(schedule => schedule.editable).map(schedule => ({
                week_day: schedule.week_day,
                time_from: schedule.time_from,
                time_to: schedule.time_to,
            }));

            const payload = {
                name: this.editedDepartment.name,
                head_of_department_id: this.editedDepartment.head_of_department_id,
                zones: zoneIds,
                timezone: 'Asia/Almaty',
                schedules: editableSchedules // Отправляем только редактируемые расписания
            };


            try {
                const response = await axios.put(`https://workpunc.xyz/api/departments/${departmentId}/`, payload, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                alert("Department updated successfully:");
                this.$router.push({ name: 'departments' });
            } catch (error) {
                console.error("Error updating employee:", error);
            }
        }, async fetchZoneList() {
                if (!this.companyId) {
                console.log("Company ID is not set");
                console.log(this.companyId)
                return;
            }
            const authToken = localStorage.getItem('authToken');
            try {
                const response = await axios.get(`https://workpunc.xyz/api/zone/?company=${this.companyId}`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.zones = response.data.results;
            } catch (error) {
                console.error("Error fetching departments", error);
            }
            },
        async fetchHeadDepartments() {
        if (!this.companyId) {
                console.log("Company ID is not set");
                console.log(this.companyId)
                return;
            }
            const authToken = localStorage.getItem('authToken');
            try {
                const response = await axios.get(`https://workpunc.xyz/api/employees/?company=${this.companyId}`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.heads = response.data.results;
            } catch (error) {
                console.error("Error fetching departments", error);
            }
        },
        removeSeconds(time) {
        const parts = time.split(':');
        return parts[0] + ':' + parts[1];
        },
        initializeSchedules() {
                const schedules = [];
                for (let i = 0; i < 7; i++) {
                    schedules.push({
                        week_day: i,
                        time_from: '',
                        time_to: '',
                        editable: false
                    });
                }
                return schedules;
            },
            toggleScheduleEditability(schedule) {
        const newEditableState = !schedule.editable;
        const updatedSchedule = { ...schedule, editable: newEditableState };
        const scheduleIndex = this.editedDepartment.schedules.findIndex(s => s === schedule);
        this.editedDepartment.schedules.splice(scheduleIndex, 1, updatedSchedule);
    },
            
        }
}
</script>

<style> 
    .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 200px;
    height: 100%;
    background-color: #333;
    color: #fff; 
    padding-top: 50px; 
  }
  
  .sidebar-header {
    padding: 20px;
    text-align: center;
  }
  
  .sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  .sidebar-menu-item {
    padding: 10px 20px;
    font-size: 18px;
  }
  
  .sidebar-menu-item a{
      color: white;
      text-decoration: none;
  }
  
  .sidebar-menu-item:hover {
    background-color: #555;
  }
  
  .choosed {
      background-color: #555;
  }
  .employee_info {
    margin-left: 200px;
  }
</style>