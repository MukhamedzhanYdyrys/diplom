<template>
    <div class="sidebar">
        <div class="sidebar-header">
          <h3>Work Punctual</h3>
        </div>
        <ul class="sidebar-menu">
          <li @click="goToDepartments" class="sidebar-menu-item"><a >Departments</a></li>
          <li @click="goToEmployees" class="sidebar-menu-item"><a >Employees</a></li>
          <li @click="goToProfile" class="sidebar-menu-item"><a >Profile</a></li>
          <li @click="goToZones" class="sidebar-menu-item"><a >Zones</a></li>
          <li @click="goToChecklists" class="sidebar-menu-item choosed"><a>Checklists</a></li>
          <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
        </ul>
    </div>
    <div class="employee_info">
        <h1>Edit checklist</h1>
        <div>
            <label for="name">Name:</label>
            <input type="text" id="name" v-model="edited_checklist.name"><br>

            <h3>Groups</h3>
            <div v-for="(group, groupIndex) in edited_checklist.groups" :key="groupIndex">
                <label for="group_name">Group Name</label>
                <input type="text" v-model="group.name"><br>
                <input type="checkbox" id="checkbox" v-model="group.checkbox">
                <label for="checkbox">With checkbox</label><br>
                <div v-for="(task, taskIndex) in group.tasks" :key="taskIndex">
                    <label for="task_name">Task Name</label>
                    <input type="text" v-model="task.name">
                </div>
                <button @click="addTask(groupIndex)">Add Task</button>
                <button @click="addGroup">Add Group</button>
            </div><br>


            <label for="executors">Executor</label>
            <select v-model="edited_checklist.executors" id="executors">
                <option v-for="executor in executors" :key="executor.user.id" :value="executor.user.id">
                    {{ executor.user.first_name }} {{ executor.user.last_name }}
                </option>
            </select><br>

            <div v-if="showScores">
            <label for="executor_reward">Executor Reward</label>
            <input type="number" v-model="edited_checklist.executor_reward"><br>
            <label for="executor_penalty_late">Executor Late</label>
            <input type="number" v-model="edited_checklist.executor_penalty_late"><br>
            <label for="executor_penalty_not_completed">Executor Not Completed</label>
            <input type="number" v-model="edited_checklist.executor_penalty_not_completed"><br>
            </div>

            <label for="inspectors">Inspector</label>
            <select v-model="edited_checklist.inspectors" id="inspectors">
                <option v-for="inspector in inspectors" :key="inspector.user.id" :value="inspector.user.id">
                    {{ inspector.user.first_name }} {{ inspector.user.last_name }}
                </option>
            </select><br> 

            <div v-if="showScores">
            <label for="inspector_reward">Inspector Reward</label>
            <input type="number" v-model="edited_checklist.inspector_reward"><br>
            <label for="inspector_penalty_late">Inspector Late</label>
            <input type="number" v-model="edited_checklist.inspector_penalty_late"><br>
            <label for="inspector_penalty_not_completed">Inspector Not Completed</label>
            <input type="number" v-model="edited_checklist.inspector_penalty_not_completed"><br>
            </div>

            <label for="department">Department:</label>
            <select v-model="edited_checklist.department" id="department">
                <option v-for="department in departments" :key="department.id" :value="department.id">
                    {{ department.name }}
                </option>
            </select><br>

            <div v-for="(schedule, index) in edited_checklist.schedules" :key="index">
                    <h3>Schedule {{ daysOfWeek[schedule.week_day] }}</h3>
                    <input type="checkbox" :id="'editable-' + index" v-model="schedule.editable">
                    <label :for="'editable-' + index">Enable Editing</label><br>

                    <label for="time_from">Time From:</label>
                    <input type="time" v-model="schedule.time_from" :disabled="!schedule.editable"><br>

                    <label for="time_to">Time To:</label>
                    <input type="time" v-model="schedule.time_to" :disabled="!schedule.editable"><br>
                </div>
            <button @click="updateChecklist">Save</button>
            </div>
    </div>

</template>

<script>
import axios from 'axios'

export default {
    data() {
        return {
            companyId: null,
            edited_checklist: {
                name: '',
                start_date: '2024-03-31',
                schedules: this.initializeSchedules(),
                groups: [ {
                    name: '',
                    checklist: 1,
                    checkbox: false,
                    tasks: [
                        {
                            name: '',
                            group: 0,
                        }
                    ],
                    },
                ],
                timezone: 'Asia/Almaty',
                company: '',
            },
            executors: [],
            departments: [],
            inspectors: [],
            daysOfWeek: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        }
    },
    created() {
        this.initialize();
    },
    methods: {
        async logout() {
            this.$root.logout();
            localStorage.removeItem('authToken');
            this.$router.push('/');
        },
        goToDepartments() {
            this.$router.push({ name: 'departments' });
        },
        goToEmployees() {
            this.$router.push({ name: 'employees' });
        },
        goToProfile() {
            this.$router.push({ name: 'profile' });
        },
        goToZones() {
            this.$router.push({ name: 'zones' });
        },
        goToChecklists() {
            this.$router.push({ name: 'Checklists' });
        },
        async initialize() {
            await this.fetchCompanyId();
            await this.fetchEmployees();
            await this.fetchDepartments();
            await this.fetchchecklist();
        },
        async fetchCompanyId() {
            const authToken = localStorage.getItem('authToken');
            try {
                const profileResponse = await axios.get(`https://workpunc.xyz/api/profile/owner/`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.companyId = profileResponse.data.selected_company.id;
                this.edited_checklist.company = this.companyId;

            } catch (error) {
                console.error("Error fetching company ID:", error);
            }
        },
        async fetchchecklist() {
            const authToken = localStorage.getItem('authToken');
            const checklistId = this.$route.query.id;
            try {
                const response = await axios.get(`https://workpunc.xyz/api/checklist/manage/${checklistId}/`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.edited_checklist = response.data;

                const existingSchedules = this.edited_checklist.schedules || [];
                const fullSchedules = this.initializeSchedules();

                this.edited_checklist.schedules = fullSchedules.map(fullSchedule => {
                    const existingSchedule = existingSchedules.find(s => s.week_day === fullSchedule.week_day);
                    return existingSchedule ? { ...fullSchedule, ...existingSchedule, editable: !!existingSchedule.time_from && !!existingSchedule.time_to } : fullSchedule;
                });
            } catch (error) {
                console.error("Error fetching employee:", error);
            }
        },
        async updateChecklist() {
    this.edited_checklist.schedules.forEach(schedule => {
        schedule.time_from = this.removeSeconds(schedule.time_from);
        schedule.time_to = this.removeSeconds(schedule.time_to);
    });

    const editableSchedules = this.edited_checklist.schedules.filter(schedule => schedule.editable).map(schedule => ({
                week_day: schedule.week_day,
                time_from: schedule.time_from,
                time_to: schedule.time_to,
            }));

    if (!Array.isArray(this.edited_checklist.executors)) {
        this.edited_checklist.executors = [this.edited_checklist.executors];
    }

    if (!Array.isArray(this.edited_checklist.inspectors)) {
        this.edited_checklist.inspectors = [this.edited_checklist.inspectors];
    }

    const dataToSend = {
        ...this.edited_checklist,
        schedules: editableSchedules
    };

    const checklistId = this.$route.query.id;
    const authToken = localStorage.getItem('authToken');
    try {
        const response = await axios.put(`https://workpunc.xyz/api/checklist/manage/${checklistId}/`, dataToSend, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        alert("Checklist updated successfully:", response.data);
        this.$router.push({ name: 'Checklists' });
    } catch (error) {
        console.error("Error update checklist", error);
    }
},async fetchEmployees() {
        if (!this.companyId) {
                console.log("Company ID is not set");
                console.log(this.companyId)
                return;
            }
            const authToken = localStorage.getItem('authToken');
            try {
                const response = await axios.get(`https://workpunc.xyz/api/employees/?company=${this.companyId}`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.executors = response.data.results;
                this.inspectors = response.data.results
            } catch (error) {
                console.error("Error fetching departments", error);
            }
        },async fetchDepartments() {
        if (!this.companyId) {
                console.log("Company ID is not set");
                console.log(this.companyId)
                return;
            }
            const authToken = localStorage.getItem('authToken');
            try {
                const response = await axios.get(`https://workpunc.xyz/api/departments/?company=${this.companyId}`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.departments = response.data.results;
            } catch (error) {
                console.error("Error fetching departments", error);
            }
        },
        addTask(groupIndex) {
            this.edited_checklist.groups[groupIndex].tasks.push({
                name: ''
            });
        },
        addGroup() {
            this.edited_checklist.groups.push({
                name: '',
                checklist: 1,
                checkbox: false,
                tasks: [
                    {
                        name: '',
                        group: this.edited_checklist.groups.length,
                    }
                ],
            });
        },
        removeSeconds(time) {
        const parts = time.split(':');
        return parts[0] + ':' + parts[1];
    },
    initializeSchedules() {
                const schedules = [];
                for (let i = 0; i < 7; i++) {
                    schedules.push({
                        week_day: i,
                        time_from: '',
                        time_to: '',
                        editable: false
                    });
                }
                return schedules;
            },
            toggleScheduleEditability(schedule) {
        const newEditableState = !schedule.editable;
        const updatedSchedule = { ...schedule, editable: newEditableState };
        const scheduleIndex = this.edited_checklist.schedules.findIndex(s => s === schedule);
        this.edited_checklist.schedules.splice(scheduleIndex, 1, updatedSchedule);
    },
    },
    computed: {
    showScores() {
        for (let group of this.edited_checklist.groups) {
            if (group.checkbox) {
                return true;
            }
        }
        return false;
    }
}
    }
</script>

<style> 
    .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 200px;
    height: 100%;
    background-color: #333;
    color: #fff; 
    padding-top: 50px; 
  }
  
  .sidebar-header {
    padding: 20px;
    text-align: center;
  }
  
  .sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  .sidebar-menu-item {
    padding: 10px 20px;
    font-size: 18px;
  }
  
  .sidebar-menu-item a{
      color: white;
      text-decoration: none;
  }
  
  .sidebar-menu-item:hover {
    background-color: #555;
  }
  
  .choosed {
      background-color: #555;
  }
  .employee_info {
    margin-left: 200px;
  }
</style>