<template>
    <div class="sidebar">
        <div class="sidebar-header">
          <h3>Work Punctual</h3>
        </div>
        <ul class="sidebar-menu">
          <li @click="goToDepartments" class="sidebar-menu-item"><a >Departments</a></li>
          <li @click="goToEmployees" class="sidebar-menu-item choosed"><a >Employees</a></li>
          <li @click="goToProfile" class="sidebar-menu-item"><a >Profile</a></li>
          <li @click="goToZones" class="sidebar-menu-item"><a >Zones</a></li>
          <li @click="goToChecklists" class="sidebar-menu-item"><a>Checklists</a></li>
          <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
        </ul>
    </div>
    <div class="employee_info">
        <!-- Поля для редактирования данных сотрудника -->
        <h1>Edit Employee</h1>
        <form @submit.prevent="createEmployee">
            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" v-model="pendingEmployee.first_name"><br>
            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" v-model="pendingEmployee.last_name"><br>
            <label for="middle_name">Middle Name:</label>
            <input type="text" id="middle_name" v-model="pendingEmployee.middle_name"><br>
            <label for="email">Email:</label>
            <input type="email" id="email" v-model="pendingEmployee.email"><br>
            <label for="phone_number">Phone Number:</label>
            <input type="text" id="phone_number" v-model="pendingEmployee.phone_number"><br>
            <input type="checkbox" id="in_zone" v-model="pendingEmployee.in_zone">
            <label for="in_zone">In zone:</label><br>
            <input type="checkbox" id="checkout_any_time" v-model="pendingEmployee.checkout_any_time">
            <label for="checkout_any_time">Checkout any time</label><br>
            <label for="checkout_time">Checkout time</label>
            <input type="number" id="checkout_time" v-model="pendingEmployee.checkout_time"><br>
            <label for="title">Position:</label>
            <input type="text" id="title" v-model="pendingEmployee.title"><br>
            <label for="grade">Grade:</label>
            <input type="number" id="grade" v-model="pendingEmployee.grade"><br>

            <label for="zones">Zone</label>
            <select v-model="pendingEmployee.zones" multiple id="zones">
                <option v-for="zone in selectedZones" :key="zone.id" :value="zone.id">
                    {{ zone.address }}
                </option>
            </select><br>

            <label for="department">Department:</label>
            <select v-model="pendingEmployee.department_id" id="department">
                <option v-for="department in departments" :key="department.id" :value="department.id">
                    {{ department.name }}
                </option>
            </select><br>

            <div v-for="(schedule, index) in pendingEmployee.schedules" :key="index">
                    <h3>Schedule {{ daysOfWeek[schedule.week_day] }}</h3>
                    <input type="checkbox" :id="'editable-' + index" v-model="schedule.editable">
                    <label :for="'editable-' + index">Enable Editing</label><br>

                    <label for="time_from">Time From:</label>
                    <input type="time" v-model="schedule.time_from" :disabled="!schedule.editable"><br>

                    <label for="time_to">Time To:</label>
                    <input type="time" v-model="schedule.time_to" :disabled="!schedule.editable"><br>

                    <input type="checkbox" v-model="schedule.is_night_shift" :disabled="!schedule.editable">
                    <label for="is_night_shift">Night Shift</label><br>
                </div>
            <button type="submit">Save Changes</button>
        </form>
    </div>

</template>

<script>
import axios from 'axios'

export default {
    data() {
        return {
            companyId: null,
            selectedZones: [],
            editingMode: false,
            pendingEmployee: {
                first_name: '',
                last_name: '',
                middle_name: '',
                email: '',
                phone_number: '',
                in_zone: false,
                checkout_any_time: false,
                checkout_time: '',
                zones: [],
                schedules: this.initializeSchedules(),
            },
            departments: [],
            daysOfWeek: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        }
    },created() {
        this.initialize();
    },
    methods: {
        async logout() {
            this.$root.logout();
            localStorage.removeItem('authToken');
            this.$router.push('/');
        },
        goToDepartments() {
            this.$router.push({ name: 'departments' });
        },
        goToEmployees() {
            this.$router.push({ name: 'employees' });
        },
        goToProfile() {
              this.$router.push({ name: 'profile' });
        },
        goToZones() {
              this.$router.push({ name: 'zones' });
        },
        goToChecklists() {
            this.$router.push({ name: 'Checklists' });
        },
        async initialize() {
            await this.fetchCompanyId();
            await this.fetchZoneList();
            await this.fetchPendingEmployee();
            await this.fetchDepartments();
        },
        async fetchCompanyId() {
                const authToken = localStorage.getItem('authToken');
                try {
                    const profileResponse = await axios.get(`https://workpunc.xyz/api/profile/owner/`, {
                        headers: {
                            'Authorization': `Bearer ${authToken}`,
                            'Content-Type': 'application/json'
                        }
                    });
                    this.companyId = profileResponse.data.selected_company.id; 
                } catch (error) {
                    console.error("Error fetching company ID:", error);
                }
            },
    async fetchPendingEmployee() {

    const authToken = localStorage.getItem('authToken');
    const pending_employeeId = this.$route.query.id; // Получаем ID из параметров маршрута
    if (!pending_employeeId) {
        console.error("Employee ID is not provided");
        return;
    }
    try {
        const response = await axios.get(`https://workpunc.xyz/api/employees/pending/?company=${this.companyId}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        const employee = response.data.results.find(e => e.id.toString() === pending_employeeId);
        this.pendingEmployee = employee;
        
        const existingSchedules = this.pendingEmployee.schedules || [];
                const fullSchedules = this.initializeSchedules();

                this.pendingEmployee.schedules = fullSchedules.map(fullSchedule => {
                    const existingSchedule = existingSchedules.find(s => s.week_day === fullSchedule.week_day);
                    return existingSchedule ? { ...fullSchedule, ...existingSchedule, editable: !!existingSchedule.time_from && !!existingSchedule.time_to } : fullSchedule;
                });
    } catch (error) {
        console.error("Error fetching employees:", error);
    }
},
        async fetchZoneList() {
            if (!this.companyId) {
            console.log("Company ID is not set");
            console.log(this.companyId)
            return;
        }
        const authToken = localStorage.getItem('authToken');
        try {
            const response = await axios.get(`https://workpunc.xyz/api/zone/?company=${this.companyId}`, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });
            this.selectedZones = response.data.results;
        } catch (error) {
            console.error("Error fetching departments", error);
        }
        },
        async createEmployee() {
            const selectedZoneId = this.pendingEmployee.zones;
            const zoneIds = Array.isArray(selectedZoneId) ? selectedZoneId : [selectedZoneId];
            this.pendingEmployee.zones = zoneIds;

            const authToken = localStorage.getItem('authToken');
            const employeeData = { ...this.pendingEmployee }; 

            const editableSchedules = this.pendingEmployee.schedules.filter(schedule => schedule.editable).map(schedule => ({
                week_day: schedule.week_day,
                time_from: schedule.time_from,
                time_to: schedule.time_to,
                is_night_shift: schedule.is_night_shift,
            }));

            const payload = {
                first_name: this.pendingEmployee.first_name,
                last_name: this.pendingEmployee.last_name,
                middle_name: this.pendingEmployee.middle_name,
                email: this.pendingEmployee.email,
                phone_number: this.pendingEmployee.phone_number,
                in_zone: !!this.pendingEmployee.in_zone,
                checkout_any_time: !!this.pendingEmployee.checkout_any_time,
                checkout_time: this.pendingEmployee.checkout_time,
                title: this.pendingEmployee.title,
                grade: this.pendingEmployee.grade,
                department_id: this.pendingEmployee.department_id,
                schedules: this.pendingEmployee.schedules.map(schedule => ({
                    week_day: schedule.week_day,
                    time_from: schedule.time_from,
                    time_to: schedule.time_to,
                    is_night_shift: schedule.is_night_shift,
                })),
                schedules: editableSchedules,
                zones: Array.isArray(this.pendingEmployee.zones) ? this.pendingEmployee.zones : [this.pendingEmployee.zones],
            }
    const filteredSchedules = this.pendingEmployee.schedules.filter(schedule => schedule.editable);


    filteredSchedules.forEach(schedule => {
        schedule.time_from = this.removeSeconds(schedule.time_from);
        schedule.time_to = this.removeSeconds(schedule.time_to);
    });
    try {
        const response = await axios.post(`https://workpunc.xyz/api/employees/`, payload, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        alert("Employee created successfully:", response.data);
        this.deletePendingEmployee(this.pendingEmployee.id)
    } catch (error) {
        console.error("Error creating employee:", error);
    }
},
async fetchDepartments() {
        if (!this.companyId) {
                console.log("Company ID is not set");
                console.log(this.companyId)
                return;
            }
            const authToken = localStorage.getItem('authToken');
            try {
                const response = await axios.get(`https://workpunc.xyz/api/departments/?company=${this.companyId}`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.departments = response.data.results;
            } catch (error) {
                console.error("Error fetching departments", error);
            }
        },
        async deletePendingEmployee(EmployeeIdDelete) {
            const authToken = localStorage.getItem('authToken');
            try {
              await axios.delete(`https://workpunc.xyz/api/employees/pending/${EmployeeIdDelete}/`, {
                headers: {
                  'Authorization': `Bearer ${authToken}`,
                  'Content-Type': 'application/json'
                }
              });
              this.$router.push({ name: 'employees' });
            } catch (error) {
              console.error("Error deleting employee:", error);
              alert('Failed to delete');
            }
            },
            addSchedule(Index) {
            this.pendingEmployee.schedules.push({
                week_day: null,
                time_from: '',
                time_to: '',
                is_night_shift: false
            });
        },

        initializeSchedules() {
                const schedules = [];
                for (let i = 0; i < 7; i++) {
                    schedules.push({
                        week_day: i,
                        time_from: '',
                        time_to: '',
                        is_night_shift: false,
                        editable: false
                    });
                }
                return schedules;
            },
            toggleScheduleEditability(schedule) {
        const newEditableState = !schedule.editable;
        const updatedSchedule = { ...schedule, editable: newEditableState };
        const scheduleIndex = this.pendingEmployee.schedules.findIndex(s => s === schedule);
        this.pendingEmployee.schedules.splice(scheduleIndex, 1, updatedSchedule);
    },
        removeSeconds(time) {
        const parts = time.split(':');
        return parts[0] + ':' + parts[1];
        },
            
        }
}
</script>

<style> 
    .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 200px;
    height: 100%;
    background-color: #333;
    color: #fff; 
    padding-top: 50px; 
  }
  
  .sidebar-header {
    padding: 20px;
    text-align: center;
  }
  
  .sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  .sidebar-menu-item {
    padding: 10px 20px;
    font-size: 18px;
  }
  
  .sidebar-menu-item a{
      color: white;
      text-decoration: none;
  }
  
  .sidebar-menu-item:hover {
    background-color: #555;
  }
  
  .choosed {
      background-color: #555;
  }
  .employee_info {
    margin-left: 200px;
  }
</style>