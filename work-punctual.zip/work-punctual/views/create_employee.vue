<template>
    <div class="sidebar">
        <div class="sidebar-header">
          <h3>Work Punctual</h3>
        </div>
        <ul class="sidebar-menu">
          <li @click="goToDepartments" class="sidebar-menu-item"><a >Departments</a></li>
          <li @click="goToEmployees" class="sidebar-menu-item choosed"><a >Employees</a></li>
          <li @click="goToProfile" class="sidebar-menu-item"><a >Profile</a></li>
          <li @click="goToZones" class="sidebar-menu-item"><a >Zones</a></li>
          <li @click="goToChecklists" class="sidebar-menu-item"><a>Checklists</a></li>
          <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
        </ul>
    </div>
    <div class="employee_info">
        <!-- Поля для редактирования данных сотрудника -->
        <h1>Create Employee</h1>
        <form @submit.prevent="createEmployee">
            <label for="first_name">First Name:</label>
            <input required type="text" id="first_name" v-model="create_employee.first_name"><br>
            <label required for="last_name">Last Name:</label>
            <input required type="text" id="last_name" v-model="create_employee.last_name"><br>
            <label for="middle_name">Middle Name:</label>
            <input required type="text" id="middle_name" v-model="create_employee.middle_name"><br>
            <label for="email">Email(example@gmail.com):</label>
            <input required type="email" id="email" v-model="create_employee.email"><br>
            <label for="phone_number">Phone Number:</label>
            <input required type="text" id="phone_number" v-model="create_employee.phone_number"><br>
            <input type="checkbox" id="in_zone" v-model="create_employee.in_zone">
            <label for="in_zone">In zone:</label><br>
            <input type="checkbox" id="checkout_any_time" v-model="create_employee.checkout_any_time">
            <label for="checkout_any_time">Checkout any time</label><br>
            <label for="checkout_time">Checkout time</label>
            <input max="15" min="1" required type="number" id="checkout_time" v-model="create_employee.checkout_time"><br>
            <label for="title">Position:</label>
            <input required type="text" id="title" v-model="create_employee.title"><br>
            <label for="grade">Grade:</label>
            <input max="4" min="1" required type="number" id="grade" v-model="create_employee.grade"><br>

            <label for="department">Department:</label>
            <select required v-model="create_employee.department_id" id="department">
                <option v-for="department in departments" :key="department.id" :value="department.id">
                    {{ department.name }}
                </option>
            </select><br>

            <label for="zones">Zone</label>
            <select required v-model="create_employee.zones" multiple id="zones">
                <option v-for="zone in selectedZones" :key="zone.id" :value="zone.id">
                    {{ zone.address }}
                </option>
            </select><br>

            <div v-for="(schedule, index) in create_employee.schedules" :key="index">
                    <h3>Schedule {{ daysOfWeek[schedule.week_day] }}</h3>
                    <input type="checkbox" :id="'editable-' + index" v-model="schedule.editable">
                    <label :for="'editable-' + index">Enable Editing</label><br>

                    <label for="time_from">Time From:</label>
                    <input required type="time" v-model="schedule.time_from" :disabled="!schedule.editable"><br>

                    <label for="time_to">Time To:</label>
                    <input required type="time" v-model="schedule.time_to" :disabled="!schedule.editable"><br>

                    <input type="checkbox" v-model="schedule.is_night_shift" :disabled="!schedule.editable">
                    <label for="is_night_shift">Night Shift</label><br>
                </div>

            <button type="submit">Create</button>
        </form>
    </div>

</template>

<script>
import axios from 'axios'

export default {
    data() {
        return {
            companyId: null,
            selectedZones: [],
            editingMode: false,
            create_employee: {
                user: {
                    first_name: '',
                    last_name: '',
                    middle_name: '',
                    email: '',
                    phone_number: ''
                },
                grade: null,
                score: null,
                in_zone: false,
                checkout_any_time: false,
                checkout_time: '',
                zones: [],
                schedules: this.initializeSchedules(),
            },
            departments: [],
            daysOfWeek: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        }
    },
    created() {
        this.initialize();
    },
    methods: {
        async logout() {
            this.$root.logout();
            localStorage.removeItem('authToken');
            this.$router.push('/');
        },
        goToDepartments() {
            this.$router.push({ name: 'departments' });
        },
        goToEmployees() {
            this.$router.push({ name: 'employees' });
        },
        goToProfile() {
            this.$router.push({ name: 'profile' });
        },
        goToZones() {
            this.$router.push({ name: 'zones' });
        },
        goToChecklists() {
            this.$router.push({ name: 'Checklists' });
        },
        async initialize() {
            await this.fetchCompanyId();
            await this.fetchZoneList();
            await this.fetchDepartments();

        },
        async fetchCompanyId() {
            const authToken = localStorage.getItem('authToken');
            try {
                const profileResponse = await axios.get(`https://workpunc.xyz/api/profile/owner/`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.companyId = profileResponse.data.selected_company.id;
            } catch (error) {
                console.error("Error fetching company ID:", error);
            }
        },
        async createEmployee() {
    if (this.create_employee.schedules.length === 0) {
        this.create_employee.schedules.push({
            week_day: null,
            time_from: '',
            time_to: '',
            is_night_shift: false
        });
    }

    const filteredSchedules = this.create_employee.schedules.filter(schedule => schedule.editable);


    filteredSchedules.forEach(schedule => {
        schedule.time_from = this.removeSeconds(schedule.time_from);
        schedule.time_to = this.removeSeconds(schedule.time_to);
    });
    
    if (!this.selectedZones) {
        console.error("Selected zones not initialized.");
        return;
    }

    const selectedZoneId = this.create_employee.zones;
    const zoneIds = Array.isArray(selectedZoneId) ? selectedZoneId : [selectedZoneId];
    this.create_employee.zones = zoneIds;
    const authToken = localStorage.getItem('authToken');
    const employeeToCreate = {
            ...this.create_employee,
            schedules: filteredSchedules 
        };
    try {
        const response = await axios.post(`https://workpunc.xyz/api/employees/`, employeeToCreate, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        alert("Employee created successfully:", response.data);
        this.$router.push({ name: 'employees' });
    } catch (error) {
    console.error(error.response ? error.response.data : error);
    let errorMessage = error.response && error.response.data ? error.response.data.message : null;
    if(errorMessage) {
        switch(errorMessage) {
            case('Уже есть пользователь с такой почтой'):
                alert('Уже есть пользователь с такой почтой');
                break;
            default:
                alert(errorMessage);
        }
    } else {
        console.error("An unexpected error occurred", error);
    }
}
}

,async fetchZoneList() {
            if (!this.companyId) {
                console.log("Company ID is not set");
                console.log(this.companyId)
                return;
            }
            const authToken = localStorage.getItem('authToken');
            try {
                const response = await axios.get(`https://workpunc.xyz/api/zone/?company=${this.companyId}`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.selectedZones = response.data.results;
            } catch (error) {
                console.error("Error fetching departments", error);
            }
        },async fetchDepartments() {
        if (!this.companyId) {
                console.log("Company ID is not set");
                console.log(this.companyId)
                return;
            }
            const authToken = localStorage.getItem('authToken');
            try {
                const response = await axios.get(`https://workpunc.xyz/api/departments/?company=${this.companyId}`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.departments = response.data.results;
            } catch (error) {
                console.error("Error fetching departments", error);
            }
        },
        initializeSchedules() {
                const schedules = [];
                for (let i = 0; i < 7; i++) {
                    schedules.push({
                        week_day: i,
                        time_from: '',
                        time_to: '',
                        is_night_shift: false,
                        editable: false
                    });
                }
                return schedules;
            },
            toggleScheduleEditability(schedule) {
        const newEditableState = !schedule.editable;
        const updatedSchedule = { ...schedule, editable: newEditableState };
        const scheduleIndex = this.create_employee.schedules.findIndex(s => s === schedule);
        this.create_employee.schedules.splice(scheduleIndex, 1, updatedSchedule);
    },

        removeSeconds(time) {
        const parts = time.split(':');
        return parts[0] + ':' + parts[1];
        },
    },
    }
</script>

<style> 
    .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 200px;
    height: 100%;
    background-color: #333;
    color: #fff; 
    padding-top: 50px; 
  }
  
  .sidebar-header {
    padding: 20px;
    text-align: center;
  }
  
  .sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  .sidebar-menu-item {
    padding: 10px 20px;
    font-size: 18px;
  }
  
  .sidebar-menu-item a{
      color: white;
      text-decoration: none;
  }
  
  .sidebar-menu-item:hover {
    background-color: #555;
  }
  
  .choosed {
      background-color: #555;
  }
  .employee_info {
    margin-left: 200px;
  }
</style>