<template>
    <div class="form-container">
      <h3>First Name</h3>
      <input class="form-input" v-model="first_name" type="text" placeholder="First Name">
      <h3>Last Name</h3>
      <input class="form-input" v-model="last_name" type="text" placeholder="Last Name">
      <h3>Middle Name</h3>
      <input class="form-input" v-model="middle_name" type="text" placeholder="Middle Name">
      <h3>Email(example@test.kz)</h3>
      <input class="form-input" v-model="email" type="text" placeholder="Email(example@test.kz)" >
      <h3>Company Name</h3>
      <input class="form-input" v-model="company_name" type="text" placeholder="Compamy Name">
      <h3>Company Legal Name</h3>
      <input class="form-input" v-model="company_legal_name" type="text" placeholder="Compamy legal Name">
      <h3>Max Employee</h3>
      <input class="form-input" v-model="max_employees_qty" type="number" placeholder="Max Employee">
      <h3>Years Of Work</h3>
      <input class="form-input" v-model="years_of_work" type="number" placeholder="Years Of Work">
      <h3>Password</h3>
      <input class="form-input" v-model="password" type="password" placeholder="Password">
      <button class="form-button" @click="submitForm">Submit</button>
    </div>
</template>

<script>
import axios from 'axios'
import {useRouter} from 'vue-router';

export default {
  setup() {
      const router = useRouter();
      return { router };
    }, 
    created() {
        this.otp_token = this.$route.query.otp_token;
    }, 
  data() {
    return {
            first_name: '',
            last_name: '',
            middle_name: '',
            email: '',
            otp_token: '',
            company_name: '',
            company_legal_name: '',
            max_employees_qty: '',
            years_of_work: '',
            password: '',

        };
    },
    methods: {
      async submitForm() {
            if (
          !this.first_name ||
          !this.last_name ||
          !this.middle_name ||
          !this.email ||
          !this.company_name ||
          !this.company_legal_name ||
          !this.max_employees_qty ||
          !this.years_of_work ||
          !this.password
        ) {
          alert('Please fill in all fields');
          return;
        }

        const data = {
            first_name: this.first_name,
            last_name: this.last_name,
            middle_name: this.middle_name,
            email: this.email,
            otp_token: this.otp_token,
            company_name: this.company_name,
            company_legal_name: this.company_legal_name,
            max_employees_qty: this.max_employees_qty,
            years_of_work: this.years_of_work,
            password: this.password,
        };
  
        try {
          const response = await axios.post('https://workpunc.xyz/api/company/', data, {
            headers: {
              'Content-Type': 'application/json'
            }
          });
          alert('success');
          this.$router.push({ name: 'Login'});
        } catch (error) {
            console.error(error.response ? error.response.data : error);
            if (error.response) {
              switch (error.response.data.message) {
                case 'Уже есть пользователь с такой почтой':
                  alert('User with this email already exists');
                  break;
                  case 'Компания с таким названием уже существует':
                  alert('Company with this name already exists');
                  break;
                default:
                  alert('Error');
            }
      } 
      }
    }
    }
}
</script>

<style scoped>
.form-container {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    background-color: #f7f7f7;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  .form-input {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box; 
  }
  
  .form-button {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 4px;
    background-color: #007bff;
    color: white;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
  }
  
  .form-button:hover {
    background-color: #0056b3;
  }
</style>
