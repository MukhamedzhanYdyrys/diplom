<template>
<div class="sidebar">
        <div class="sidebar-header">
          <h3>Work Punctual</h3>
        </div>
        <ul class="sidebar-menu">
          <li @click="goToDepartments" class="sidebar-menu-item"><a >Departments</a></li>
          <li @click="goToEmployees" class="sidebar-menu-item"><a >Employees</a></li>
          <li @click="goToProfile" class="sidebar-menu-item"><a >Profile</a></li>
          <li @click="goToZones" class="sidebar-menu-item"><a >Zones</a></li>
          <li @click="goToChecklists" class="sidebar-menu-item choosed"><a>Checklists</a></li>
          <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
        </ul>
    </div>


    <div class="checklists">
        <h1>Checklists</h1>
        <button @click="goToCreateChecklists()">Create cheklist</button>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="checklist in checklists.results" :key="checklist.id">
                    <td>{{ checklist.id }}</td>
                    <td>{{ checklist.name }}</td>
                    <td>{{ checklist.department_name }}</td>
                    <td><button @click="openChecklist(checklist.id)">Open</button>
                        <button @click="deleteChecklist(checklist.id)">delete</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
import axios from 'axios'

export default {
    data() {
        return {
            checklists: []
        }
    },
    created() {
            this.fetchchecklists();
    },
    methods: {
        async logout() {
            this.$root.logout();
            localStorage.removeItem('authToken');
            this.$router.push('/');
        },
        goToDepartments() {
            this.$router.push({ name: 'departments' });
        },
        goToEmployees() {
            this.$router.push({ name: 'employees' });
        },
        goToProfile() {
            this.$router.push({ name: 'profile' });
        },
        goToZones() {
            this.$router.push({ name: 'zones' });
        },
        goToChecklists() {
            this.$router.push({ name: 'Checklists' });
        },
        goToCreateChecklists() {
            this.$router.push({ name: 'create_checklist' });
        },
        async fetchchecklists() {
        const authToken = localStorage.getItem('authToken');
        try {
            const response = await axios.get('https://workpunc.xyz/api/checklist/manage/', {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });
            this.checklists = response.data;
        } catch (error) {
            console.error("Error fetching checklists", error);
        }
        },
        async deleteChecklist(checklistId) {
          const authToken = localStorage.getItem('authToken');
          if (confirm('Are you sure you want to delete this checklist?')) {
            try {
              await axios.delete(`https://workpunc.xyz/api/checklist/manage/${checklistId}/`, {
                headers: {
                  'Authorization': `Bearer ${authToken}`,
                  'Content-Type': 'application/json'
                }
              });
              alert('Checklist deleted successfully!');
              this.fetchchecklists();
            } catch (error) {
              alert('Failed to delete');
            }
          }
        },async openChecklist(checklistId) {
          this.$router.push({ name: 'checklist', query: { id: checklistId } });
        },
    }
}
</script>

<style>
.checklists {
    margin-left: 200px;
}
</style>