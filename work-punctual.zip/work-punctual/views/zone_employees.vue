<template>
    <div class="sidebar">
        <div class="sidebar-header">
          <h3>Work Punctual</h3>
        </div>
        <ul class="sidebar-menu">
          <li @click="goToDepartments" class="sidebar-menu-item"><a >Departments</a></li>
          <li @click="goToEmployees" class="sidebar-menu-item"><a >Employees</a></li>
          <li @click="goToProfile" class="sidebar-menu-item"><a >Profile</a></li>
          <li @click="goToZones" class="sidebar-menu-item choosed"><a >Zones</a></li>
          <li @click="goToChecklists" class="sidebar-menu-item"><a>Checklists</a></li>
          <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
        </ul>
        </div>
    
        <div class="list_zones">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="zone_employees in zones_employees.employees" :key="zone_employees.id">
                        <td>{{ zone_employees.id }}</td>
                        <td>{{ zone_employees.user.first_name }}</td>
                        <td>{{ zone_employees.user.last_name }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </template>
    
    
    <script>
    import axios from 'axios'
    //chrome.exe --user-data-dir="C://chrome-dev-disabled-security" --disable-web-security --disable-site-isolation-trials
    export default {
        data() {
            return {
                zones_employees: [],
            }
        },
        created() {
            this.fetchZonesEmployees();
        },
        methods: {
            logout() {
                this.$root.logout();
                localStorage.removeItem('authToken');
                this.$router.push('/');
              },
              goToDepartments() {
              this.$router.push({ name: 'departments' });
              },
              goToEmployees() {
              this.$router.push({ name: 'employees' });
              },
              goToProfile() {
              this.$router.push({ name: 'profile' });
              },
              goToZones() {
              this.$router.push({ name: 'zones' });
              },
              goToChecklists() {
            this.$router.push({ name: 'Checklists' });
            },
            async fetchZonesEmployees() {
        const authToken = localStorage.getItem('authToken');
        const zoneId = this.$route.query.id;
        try {
            const response = await axios.get(`https://workpunc.xyz/api/zone/${zoneId}`, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });
            this.zones_employees = response.data;
        } catch (error) {
            console.error("Error fetching departments", error);
        }
    },
  }
}
    </script>
    <style>
    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        width: 200px;
        height: 100%;
        background-color: #333;
        color: #fff; 
        padding-top: 50px; 
      }
      
      .sidebar-header {
        padding: 20px;
        text-align: center;
      }
      
      .sidebar-menu {
        list-style: none;
        padding: 0;
        margin: 0;
      }
      
      .sidebar-menu-item {
        padding: 10px 20px;
        font-size: 18px;
      }
      
      .sidebar-menu-item a{
          color: white;
          text-decoration: none;
      }
      
      .sidebar-menu-item:hover {
        background-color: #555;
      }
      
      .choosed {
          background-color: #555;
      }
      .list_zones {
        margin-left: 200px;
      }
      table {
      border-collapse: collapse;
      width: 100%;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      margin-top: 20px;
    }
    
    td, th {
      border: 1px solid #dee2e6;
      text-align: left;
      padding: 12px;
    }
    
    th {
      background-color: #f8f9fa;
      color: #343a40;
    }
    
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    button {
      padding-right: 15px;
      padding-left: 15px;
      padding-top: 10px;
      font-size: medium;
      padding-bottom:10px;
      border-radius: 5px;
      background-color: #333;
      color: white;
      margin-left: 5px;
    }
    button:hover {
      background-color: #555;
    }
    label {
      font-size: large;
      margin-right: 10px;
    }
    input {
      padding-left: 15px;
      padding-right: 15px;
      padding-top: 10px;
      padding-bottom: 10px;
      border-radius: 5px;
      margin-bottom: 8px;
    }
    </style>