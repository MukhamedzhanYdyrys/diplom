<template>
    <div class="sidebar">
        <div class="sidebar-header">
          <h3>Work Punctual</h3>
        </div>
        <ul class="sidebar-menu">
          <li @click="goToDepartments" class="sidebar-menu-item"><a >Departments</a></li>
          <li @click="goToEmployees" class="sidebar-menu-item"><a >Employees</a></li>
          <li @click="goToProfile" class="sidebar-menu-item"><a >Profile</a></li>
          <li @click="goToZones" class="sidebar-menu-item choosed"><a >Zones</a></li>
          <li @click="goToChecklists" class="sidebar-menu-item"><a>Checklists</a></li>
          <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
        </ul>
        </div>
    
        <div class="list_zones">

          <button @click="toggleCreateZoneForm">Create Zone</button>

          <div class="create-zone-form" v-if="showCreateZoneForm">
    <input v-model="newZone.address" placeholder="Address">
    <input v-model="newZone.latitude" type="number" step="any" placeholder="Latitude">
    <input v-model="newZone.longitude" type="number" step="any" placeholder="Longitude">
    <input v-model="newZone.radius" type="number" placeholder="Radius">
    <select v-model="newZone.employees" multiple>
            <option v-for="employee in employees" :key="employee.id" :value="employee.id">
                {{ employee.user.first_name }}
            </option>
    </select>
    <button @click="createZone">Create Zone</button>
    <button @click="showCreateZoneForm = false">Close</button>
</div>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Address</th>
                        <th>Latitude</th>
                        <th>Longitude</th>
                        <th>Radius</th>
                        <th>Employees</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
<tr v-for="(zone, index) in zones.results" :key="zone.id">
  <td>{{ zone.id }}</td>
  <td>
    <input v-model="zone.address" :disabled="!zone.editing">
  </td>
  <td>
    <input v-model="zone.latitude" :disabled="!zone.editing">
  </td>
  <td>
    <input v-model="zone.longitude" :disabled="!zone.editing">
  </td>
  <td>
    <input v-model="zone.radius" :disabled="!zone.editing">
  </td>
<select v-model="zone.selectedEmployees" multiple :disabled="!zone.editing">
    <option v-for="employee in employees" :key="employee.id" :value="employee.id">
        {{ employee.user.first_name }}
    </option>
</select>


  <td>
    <button v-if="!zone.editing" @click="startEdit(zone)">Edit</button>
    <button v-if="zone.editing" @click="saveEdit(zone)">Save</button>
    <button v-if="zone.editing" @click="cancelEdit(zone)">Cancel</button>
    <button @click="deleteZone(zone.id)">Delete</button>
  </td>
</tr>


</tbody>

            </table>
        </div>
    </template>
    
    
    <script>
    import axios from 'axios'
    //chrome.exe --user-data-dir="C://chrome-dev-disabled-security" --disable-web-security --disable-site-isolation-trials
    export default {
      data() {
        return {
            zones: [],
            companyId: null,
            newZone: {
                address: '',
                latitude: null,
                longitude: null,
                radius: null,
                employees: []
            },
            employees: [],
            showCreateZoneForm: false,
            editingZoneId: null,
 
        };
    },
        created() {
            this.initialize();
        },
        methods: {
            logout() {
                this.$root.logout();
                localStorage.removeItem('authToken');
                this.$router.push('/');
              },
              goToDepartments() {
              this.$router.push({ name: 'departments' });
              },
              goToEmployees() {
              this.$router.push({ name: 'employees' });
              },
              goToProfile() {
              this.$router.push({ name: 'profile' });
              },
              goToZones() {
              this.$router.push({ name: 'zones' });
              },
              goToChecklists() {
            this.$router.push({ name: 'Checklists' });
            },
              async initialize() {
            await this.fetchCompanyId();
            await this.fetchZones();
            await this.fetchEmployees(); // Добавьте этот вызов
        },
            async fetchCompanyId() {
                const authToken = localStorage.getItem('authToken');
                try {
                    const profileResponse = await axios.get(`https://workpunc.xyz/api/profile/owner/`, {
                        headers: {
                            'Authorization': `Bearer ${authToken}`,
                            'Content-Type': 'application/json'
                        }
                    });
                    this.companyId = profileResponse.data.selected_company.id; 
                } catch (error) {
                    console.error("Error fetching company ID:", error);
                }
            },
            async fetchZones() {
        if (!this.companyId) {
            console.log("Company ID is not set");
            return;
        }
        const authToken = localStorage.getItem('authToken');
        try {
            const response = await axios.get(`https://workpunc.xyz/api/zone/?company=${this.companyId}`, {
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });
            this.zones = response.data;
        } catch (error) {
            console.error("Error fetching departments", error);
        }
    },    
    async openZoneEmployees(zoneId) {
          this.$router.push({ name: 'zone_employees', query: { id: zoneId } });
        },
        async createZone() {
    const authToken = localStorage.getItem('authToken');
    try {
        await axios.post(`https://workpunc.xyz/api/zone/`, {
            ...this.newZone,
            company: this.companyId,
            employees: this.newZone.employees // Используйте this.newZone.employees
            
        }, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        alert('Zone created successfully!');
        this.fetchZones(); // Обновляем список зон
    } catch (error) {
        console.error("Error creating zone:", error);
        alert('Failed to create zone');
    }
},
async fetchEmployees() {
    const authToken = localStorage.getItem('authToken');
    try {
        const response = await axios.get(`https://workpunc.xyz/api/employees/?company=${this.companyId}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        // Обновите эту строку, чтобы присвоить `this.employees` данные из `response.data.results`
        this.employees = response.data.results;
    } catch (error) {
        console.error("Error fetching employees", error);
    }},  toggleCreateZoneForm() {
    this.showCreateZoneForm = !this.showCreateZoneForm;
  }, 
  startEdit(zone) {
    zone.editing = true;
    this.editingZoneId = zone.id; // Сохраняем ID редактируемой зоны
  },

  cancelEdit(zone) {
    if (zone.id === this.editingZoneId) {
      zone.editing = false;
      this.editingZoneId = null; // Очищаем ID редактируемой зоны
      // Откат к последним сохраненным данным зоны (опционально)
    }
  },
  saveEdit(zone) {
    const authToken = localStorage.getItem('authToken');
    try {
      const updateData = {
        id: zone.id,
        address: zone.address,
        latitude: zone.latitude,
        longitude: zone.longitude,
        radius: zone.radius,
        employees: zone.selectedEmployees, // Обновленная переменная для сохранения выбранных сотрудников
        company: this.companyId
      };
      axios.put(`https://workpunc.xyz/api/zone/${zone.id}/`, updateData, {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });
      alert('Zone updated successfully!');
      this.fetchZones();
      zone.editing = false;
    this.editingZoneId = null; 
    } catch (error) {
      console.error("Error updating zone:", error);
      alert('Failed to update zone');
    }
  },
  async fetchZones() {
    const authToken = localStorage.getItem('authToken');
    if (!this.companyId) {
      console.log("Company ID is not set");
      return;
    }
    try {
      // Выполняем запрос к серверу для получения зон
      const response = await axios.get(`https://workpunc.xyz/api/zone/?company=${this.companyId}`, {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });
      // Обрабатываем ответ от сервера
      this.zones.results = response.data.results.map(zone => ({
    ...zone,
    selectedEmployees: zone.employees.map(e => e.id), // Предполагаем, что сервер возвращает ID сотрудников
    editing: false // Инициализация состояния редактирования
}));
    } catch (error) {
      console.error("Error fetching zones:", error);
    }
  },

  // ...
    // ...
    async deleteZone(zoneId) {
      const authToken = localStorage.getItem('authToken');
      if (confirm('Are you sure you want to delete this zone?')) {
        try {
          await axios.delete(`https://workpunc.xyz/api/zone/${zoneId}`, {
            headers: {
              'Authorization': `Bearer ${authToken}`,
              'Content-Type': 'application/json'
            }
          });
          alert('Zone deleted successfully!');
          this.fetchZones();
        } catch (error) {
          console.error("Error deleting zone:", error);
          alert('Failed to delete zone');
        }
      }
    },

  }
}
    </script>
    <style>
    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        width: 200px;
        height: 100%;
        background-color: #333;
        color: #fff; 
        padding-top: 50px; 
      }
      
      .sidebar-header {
        padding: 20px;
        text-align: center;
      }
      
      .sidebar-menu {
        list-style: none;
        padding: 0;
        margin: 0;
      }
      
      .sidebar-menu-item {
        padding: 10px 20px;
        font-size: 18px;
      }
      
      .sidebar-menu-item a{
          color: white;
          text-decoration: none;
      }
      
      .sidebar-menu-item:hover {
        background-color: #555;
      }
      
      .choosed {
          background-color: #555;
      }
      .list_zones {
        margin-left: 200px;
      }
      table {
      border-collapse: collapse;
      width: 100%;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      margin-top: 20px;
    }
    
    td, th {
      border: 1px solid #dee2e6;
      text-align: left;
      padding: 12px;
    }
    
    th {
      background-color: #f8f9fa;
      color: #343a40;
    }
    
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    /* Общие стили для всех инпутов и кнопок */
.input, .button, .styled-select {
  padding: 10px 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 1rem;
  color: #333;
  background-color: white;
}

/* Стили для текстовых полей */
.input {
  width: calc(33.33% - 10px); /* Вычитаем 10px, чтобы учесть отступы между полями */
  margin-right: 5px; /* Добавляем небольшой отступ справа */
  margin-bottom: 10px; /* Отступ снизу для полей */
}

/* Последнему элементу в строке не нужен правый отступ */
.input:last-child {
  margin-right: 0;
}

/* Стилизация кнопок */
.button {
  background-color: white;
  color: white;
  cursor: pointer;
  border: none; /* Убираем границу для кнопки */
  margin-bottom: 10px; /* Отступ снизу для кнопки */
  margin-left: 10px;
}

.button:hover {
  background-color: #555;
}

/* Стили для стилизованного select, включая иконку */
.select-wrapper {
  position: relative;
  width: 100%;
}

.styled-select {
  width: 100%;
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
}

.select-wrapper::after {
  content: '▼';
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
  color: #333;
}

.styled-select:focus {
  border-color: #009688;
  outline: none;
}

/* Убедитесь, что у вас есть класс 'input' для всех текстовых полей и 'button' для кнопок */
.create-zone-form > .input, .create-zone-form > .button {
  display: inline-block; /* Используем inline-block для выравнивания элементов в строку */
}

/* Стили для адаптации под мобильные устройства */
@media (max-width: 768px) {
  .input, .styled-select {
    width: 100%; /* Поля ввода будут на всю ширину на мобильных устройствах */
    margin-right: 0;
  }

  .create-zone-form > .input, .create-zone-form > .button {
    display: block; /* Ставим элементы друг под друга на мобильных устройствах */
  }
}


    </style>