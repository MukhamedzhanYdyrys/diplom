<template>
    <div class="sidebar">
        <div class="sidebar-header">
          <h3>Work Punctual</h3>
        </div>
        <ul class="sidebar-menu">
          <li @click="goToDepartments" class="sidebar-menu-item"><a >Departments</a></li>
          <li @click="goToEmployees" class="sidebar-menu-item"><a >Employees</a></li>
          <li @click="goToProfile" class="sidebar-menu-item choosed"><a >Profile</a></li>
          <li @click="goToZones" class="sidebar-menu-item"><a >Zones</a></li>
          <li @click="goToChecklists" class="sidebar-menu-item"><a>Checklists</a></li>
          <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
        </ul>
    </div>
    <div class="employee_info">
        <h1>Profile</h1>
        <h3><strong>Company Name:</strong> {{ editedProfile.selected_company.name }}</h3>
        <h3><strong>Invite Code:</strong> {{ editedProfile.selected_company.invite_code }}</h3>
        <h3><strong>Years at Work:</strong> {{ editedProfile.selected_company.years_of_work }}</h3>
        <form @submit.prevent="updateProfile">
            <label for="name"><strong>Name:</strong></label>
            <input type="text" id="name" v-model="editedProfile.first_name"><br>
            <label for="last_name"><strong>Last Name:</strong></label>
            <input type="text" id="last_name" v-model="editedProfile.last_name"><br>
            <label for="middle_name"><strong>Middle Name:</strong></label>
            <input type="text" id="middle_name" v-model="editedProfile.middle_name"><br>
            <label for="email"><strong>Email:</strong></label>
            <input type="text" id="email" v-model="editedProfile.email"><br>
            <label for="phone_number"><strong>Phone Number:</strong></label>
            <input type="text" id="phone_number" v-model="editedProfile.phone_number"><br>
            <label for="language"><strong>Language:</strong></label>
            <input type="text" id="language" v-model="editedProfile.language"><br>
            <button type="submit">Save Changes</button>
        </form>
    </div>

</template>

<script>
import axios from 'axios'

export default {
    data() {
        return {
            editedProfile: {
                first_name: '',
                last_name: '',
                middle_name: '',
                email: '',
                phone_number: '',
                language: '',
                selected_company_id: '' 
            },
        }
    },created() {
        this.fetchProfile();
    },
    methods: {
        async logout() {
            this.$root.logout();
            localStorage.removeItem('authToken');
            this.$router.push('/');
        },
        goToDepartments() {
            this.$router.push({ name: 'departments' });
        },
        goToEmployees() {
            this.$router.push({ name: 'employees' });
        },
        goToProfile() {
              this.$router.push({ name: 'profile' });
        },
        goToZones() {
              this.$router.push({ name: 'zones' });
        },
        goToChecklists() {
            this.$router.push({ name: 'Checklists' });
            },
        async fetchProfile() {
    const authToken = localStorage.getItem('authToken');
    try {
        const response = await axios.get(`https://workpunc.xyz/api/profile/owner/`, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        this.editedProfile = response.data;
    } catch (error) {
        console.error("Error fetching profile:", error);
    }
},        async updateProfile() {
    const authToken = localStorage.getItem('authToken');
    try {
        const response = await axios.patch(`https://workpunc.xyz/api/profile/owner/`, this.editedProfile, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        alert("Profile updated successfully:");
    } catch (error) {
        console.error("Error updating profile:", error);
    }
}

            
        }
}
</script>

<style> 
    .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 200px;
    height: 100%;
    background-color: #333;
    color: #fff; 
    padding-top: 50px; 
  }
  
  .sidebar-header {
    padding: 20px;
    text-align: center;
  }
  
  .sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  .sidebar-menu-item {
    padding: 10px 20px;
    font-size: 18px;
  }
  
  .sidebar-menu-item a{
      color: white;
      text-decoration: none;
  }
  
  .sidebar-menu-item:hover {
    background-color: #555;
  }
  
  .choosed {
      background-color: #555;
  }
  .employee_info {
    margin-left: 200px;
  }
</style>