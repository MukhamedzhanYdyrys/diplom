<template>
    <div class="form-container">
      <h3>Code</h3>
      <input class="form-input" type="text" v-model="code" placeholder="code">
      <p class="error">{{ errorMessage }}</p>
      <button class="form-button" @click="submitForm">Submit</button>
    </div>
</template>

<script>
import axios from 'axios'
import {useRouter} from 'vue-router';

export default {
  setup() {
      const router = useRouter();
      return { router };
    },  
  data() {
    return {
        code: '',
        otp_token: '',
        errorMessage: ''
      };
    },
    created() {
        this.otp_token = this.$route.query.otp_token;
    },
    methods: {
      async submitForm() {
        const data = {
          code: this.code,
          otp_token: this.otp_token
        };
  
        try {
          const response = await axios.post('https://workpunc.xyz/api/auth/sms/verify/', data, {
            headers: {
              'Content-Type': 'application/json'
            }
          });
          const otp_token = response.data.otp_token;
          this.$router.push({ name: 'register_owner', query: { otp_token: otp_token } });
        } catch (error) {
              console.error(error.response ? error.response.data : error);
              if (error.response) {
                  // Проверяем статус ошибки
                  switch (error.response.data.status) {
                      case 'invalid-code':
                          this.errorMessage = 'Incorrect code!'; // Устанавливаем сообщение об ошибке
                          break;
                      default:
                          this.errorMessage = error.response.data.message;
                  }
              } else {
                  this.errorMessage = error.message;
              }
          }

      }
    }
}
</script>

<style scoped>
.error {
  color: red;
}
.form-container {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    background-color: #f7f7f7;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  .form-input {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box; 
  }
  
  .form-button {
    width: 100%;
    padding: 10px;
    border: none;
    border-radius: 4px;
    background-color: #007bff;
    color: white;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
  }
  
  .form-button:hover {
    background-color: #0056b3;
  }
</style>
