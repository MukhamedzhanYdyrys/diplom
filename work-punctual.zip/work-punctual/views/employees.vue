<template>
<div class="sidebar">
    <div class="sidebar-header">
      <h3>Work Punctual</h3>
    </div>
    <ul class="sidebar-menu">
      <li @click="goToDepartments" class="sidebar-menu-item"><a >Departments</a></li>
      <li @click="goToEmployees" class="sidebar-menu-item choosed"><a >Employees</a></li>
      <li @click="goToProfile" class="sidebar-menu-item"><a >Profile</a></li>
      <li @click="goToZones" class="sidebar-menu-item"><a >Zones</a></li>
      <li @click="goToChecklists" class="sidebar-menu-item"><a>Checklists</a></li>
      <li @click="logout" class="sidebar-menu-item"><a>Log Out</a></li>
    </ul>
    </div>

    <div class="list_employees">

      <button @click="goToCreateEmployee">Create employee</button>
      <button @click="goToPendigUsers">Pending Users ({{ owner.pending_users }})</button>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Department</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="employee in employees.results" :key="employee.id">
                    <td>{{ employee.id }}</td>
                    <td>{{ employee.user.first_name }}</td>
                    <td>{{ employee.user.last_name }}</td>
                    <td>{{ employee.department.name }}</td>
                    <td><button @click="openEmployee(employee.id)">Open</button> 
                        <button @click="deleteEmployee(employee.id)">Delete</button></td>
                </tr>
            </tbody>
        </table>
    </div>
</template>


<script>
import axios from 'axios'
//chrome.exe --user-data-dir="C://chrome-dev-disabled-security" --disable-web-security --disable-site-isolation-trials
export default {
    data() {
        return {
            employees: [],
            companyId: null,
            owner: {
              pending_users: 0,
            }
        }
    },
    created() {
        this.initialize();
    },
    methods: {
        logout() {
            this.$root.logout();
            localStorage.removeItem('authToken');
            this.$router.push('/');
          },
          goToDepartments() {
          this.$router.push({ name: 'departments' });
          },
          goToEmployees() {
              this.$router.push({ name: 'employees' });
        },
        goToProfile() {
              this.$router.push({ name: 'profile' });
        },
        goToZones() {
              this.$router.push({ name: 'zones' });
        },
        goToCreateEmployee() {
          this.$router.push({name:'create_employee'})
        },
        goToPendigUsers() {
          this.$router.push({name: 'pending_users'})
        },
        goToChecklists() {
            this.$router.push({ name: 'Checklists' });
        },
          async initialize() {
        await this.fetchCompanyId();
        await this.fetchEmployees();
        await this.fetchProfile();
    },
        async fetchCompanyId() {
            const authToken = localStorage.getItem('authToken');
            try {
                const profileResponse = await axios.get(`https://workpunc.xyz/api/profile/owner/`, {
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Content-Type': 'application/json'
                    }
                });
                this.companyId = profileResponse.data.selected_company.id; 
            } catch (error) {
                console.error("Error fetching company ID:", error);
            }
        },
        async fetchEmployees() {
          if (!this.companyId) {
              console.log("Company ID is not set");
              return;
          }
          const authToken = localStorage.getItem('authToken');
          try {
              const response = await axios.get(`https://workpunc.xyz/api/employees/?company=${this.companyId}`, {
                  headers: {
                      'Authorization': `Bearer ${authToken}`,
                      'Content-Type': 'application/json'
                  }
              });
              this.employees = response.data;
          } catch (error) {
              console.error("Error fetching employees:", error);
          }
        },
        async openEmployee(employeeId) {
          this.$router.push({ name: 'employee', query: { id: employeeId } });
        },
        async deleteEmployee(EmployeeIdDelete) {
          const authToken = localStorage.getItem('authToken');
          if (confirm('Are you sure you want to delete this employee?')) {
            try {
              await axios.delete(`https://workpunc.xyz/api/employees/${EmployeeIdDelete}/`, {
                headers: {
                  'Authorization': `Bearer ${authToken}`,
                  'Content-Type': 'application/json'
                }
              });
              alert('Employee deleted successfully!');
              this.fetchEmployees();
            } catch (error) {
              console.error("Error deleting employee:", error);
              alert('Failed to delete');
            }
          }
        },
        async fetchProfile() {
    const authToken = localStorage.getItem('authToken');
    try {
        const response = await axios.get(`https://workpunc.xyz/api/profile/owner/`, {
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });
        this.owner = response.data;
    } catch (error) {
        console.error("Error fetching profile:", error);
    }
},
  

    }
}
</script>
<style>
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 200px;
    height: 100%;
    background-color: #333;
    color: #fff; 
    padding-top: 50px; 
  }
  
  .sidebar-header {
    padding: 20px;
    text-align: center;
  }
  
  .sidebar-menu {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  .sidebar-menu-item {
    padding: 10px 20px;
    font-size: 18px;
  }
  
  .sidebar-menu-item a{
      color: white;
      text-decoration: none;
  }
  
  .sidebar-menu-item:hover {
    background-color: #555;
  }
  
  .choosed {
      background-color: #555;
  }
  .list_employees {
    margin-left: 200px;
  }
  table {
  border-collapse: collapse;
  width: 100%;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
  margin-top: 20px;
}

td, th {
  border: 1px solid #dee2e6;
  text-align: left;
  padding: 12px;
}

th {
  background-color: #f8f9fa;
  color: #343a40;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}
button {
  padding-right: 15px;
  padding-left: 15px;
  padding-top: 10px;
  font-size: medium;
  padding-bottom:10px;
  border-radius: 5px;
  background-color: #333;
  color: white;
}
button:hover {
  background-color: #555;
}
label {
  font-size: large;
  margin-right: 10px;
}
input {
  padding-left: 15px;
  padding-right: 15px;
  padding-top: 10px;
  padding-bottom: 10px;
  border-radius: 5px;
  margin-bottom: 8px;
}
</style>