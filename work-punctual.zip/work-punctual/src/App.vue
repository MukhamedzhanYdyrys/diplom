<template>
    <div id="app">
      <router-view/>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
      };
    },
    computed: {
      isAuthenticated() {
        return !!localStorage.getItem('authToken');
      }
    },
    methods: {
      logout() {
        localStorage.removeItem('authToken');
        this.$router.push('/');
      }
    }
  };
  </script>
  
  <style>
  </style>
  