import { createRouter, createWebHistory } from 'vue-router';
import Login from '../views/login.vue';
import Employees from '../views/employees.vue'
import sms_send from '../views/sms_send.vue'
import sms from '../views/sms.vue'
import register_owner from '../views/register_owner.vue'
import departments from '../views/departments.vue'
import employees from '../views/employees.vue'
import employee from '../views/employee.vue'
import department from '../views/department.vue';
import profile from '../views/profile.vue'
import zones from '../views/zones.vue';
import zone_employees from '../views/zone_employees.vue';
import create_employee from '../views/create_employee.vue';
import create_department from '../views/create_department.vue';
import pending_users from '../views/pending_users.vue';
import checklists from '../views/checklists.vue'
import pending_user_create from '../views/pending_user_create.vue';
import create_checklist from '../views/create_checklist.vue';
import checklist from '../views/checklist.vue';



const routes = [
  {
    path: '/',
    name: 'Login',
    component: Login
  },
  {
    path: '/employees',
    name: 'employees',
    component: Employees,
    meta: { requiresAuth: true }
  },
  {
    path: '/sms_send',
    name: 'sms_send',
    component: sms_send,
  },
  {
    path: '/sms',
    name: 'sms',
    component: sms,
  },
  {
    path: '/register_owner',
    name: 'register_owner',
    component: register_owner,
  },
  {
    path: '/departments',
    name: 'departments',
    component: departments,
    meta: { requiresAuth: true }
  },
 {
    path: '/employees',
    name: 'employees',
    component: employees,
    meta: { requiresAuth: true }
  },
  {
    path: '/employee',
    name: 'employee',
    component: employee,
    meta: { requiresAuth: true }
  },
  {
    path: '/department',
    name: 'department',
    component: department,
    meta: { requiresAuth: true }
  },
  {
    path: '/profile',
    name: 'profile',
    component: profile,
    meta: { requiresAuth: true }
  },
  {
    path: '/zones',
    name: 'zones',
    component: zones,
    meta: { requiresAuth: true }
  },
  {
    path: '/zone_employees',
    name: 'zone_employees',
    component: zone_employees,
    meta: { requiresAuth: true }
  },
  {
    path: '/create_employee',
    name: 'create_employee',
    component: create_employee,
    meta: { requiresAuth: true }
  },
  {
    path: '/create_department',
    name: 'create_department',
    component: create_department,
    meta: { requiresAuth: true }
  },
  {
    path: '/pending_users',
    name: 'pending_users',
    component: pending_users,
    meta: { requiresAuth: true }
  },
  {
    path: '/checklists',
    name: 'Checklists',
    component: checklists,
    meta: { requiresAuth: true }
},
  {
    path: '/pending_user_create',
    name: 'pending_user_create',
    component: pending_user_create,
    meta: { requiresAuth: true }
  },
  {
    path: '/create_checklist',
    name: 'create_checklist',
    component: create_checklist,
    meta: { requiresAuth: true }
},
{
  path: '/checklist',
  name: 'checklist',
  component: checklist,
  meta: { requiresAuth: true }
},

];

const router = createRouter({
  history: createWebHistory(),
  routes
});

router.beforeEach((to, from, next) => {
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
  const isAuthenticated = localStorage.getItem('authToken');

  if (requiresAuth && !isAuthenticated) {
    next('/');
  } else {
    next();
  }
});

export default router;
